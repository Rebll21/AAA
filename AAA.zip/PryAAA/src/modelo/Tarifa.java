/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Tarifa {

    private String Nombre;
    private String Fecha;
    private String Consumo;
    private String Tarifa;

    public String getNombre() {
        return Nombre;
    }

    public String getFecha() {
        return Fecha;
    }

    public String getConsumo() {
        return Consumo;
    }

    public String getTarifa() {
        return Tarifa;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public void setConsumo(String Consumo) {
        this.Consumo = Consumo;
    }

    public void setTarifa(String Tarifa) {
        this.Tarifa = Tarifa;
    }

    public Tarifa(String Nombre, String Fecha, String Consumo, String Tarifa) {
        this.Nombre = Nombre;
        this.Fecha = Fecha;
        this.Consumo = Consumo;
        this.Tarifa = Tarifa;
    }
    
}
