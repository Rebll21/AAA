/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Facturas {
    private String Cliente;
    private String Direccion;
    private String Mes;
    private String Totalapagar;

    public String getCliente() {
        return Cliente;
    }

    public String getDireccion() {
        return Direccion;
    }

    public String getMes() {
        return Mes;
    }

    public String getTotalapagar() {
        return Totalapagar;
    }

    public void setCliente(String Cliente) {
        this.Cliente = Cliente;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public void setMes(String Mes) {
        this.Mes = Mes;
    }

    public void setTotalapagar(String Totalapagar) {
        this.Totalapagar = Totalapagar;
    }

    public Facturas(String Cliente, String Direccion, String Mes, String Totalapagar) {
        this.Cliente = Cliente;
        this.Direccion = Direccion;
        this.Mes = Mes;
        this.Totalapagar = Totalapagar;
    }

}
