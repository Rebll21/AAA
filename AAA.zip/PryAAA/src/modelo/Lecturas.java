/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Lecturas {
    
    private String Npoliza;
 private String Lecturaanterior;
 private String Lecturaactual;
 private String Nombrelector;

    public String getNpoliza() {
        return Npoliza;
    }

    public String getLecturaanterior() {
        return Lecturaanterior;
    }

    public String getLecturaactual() {
        return Lecturaactual;
    }

    public String getNombrelector() {
        return Nombrelector;
    }

    public void setNpoliza(String Npoliza) {
        this.Npoliza = Npoliza;
    }

    public void setLecturaanterior(String Lecturaanterior) {
        this.Lecturaanterior = Lecturaanterior;
    }

    public void setLecturaactual(String Lecturaactual) {
        this.Lecturaactual = Lecturaactual;
    }

    public void setNombrelector(String Nombrelector) {
        this.Nombrelector = Nombrelector;
    }

 
 
 
    public Lecturas(String Npoliza, String Lecturaanterior, String Lecturaactual, String Nombrelector) {
        this.Npoliza = Npoliza;
        this.Lecturaanterior = Lecturaanterior;
        this.Lecturaactual = Lecturaactual;
        this.Nombrelector = Nombrelector;
    }
 
 
}
