package controlador;
import vista.FrmLogin;
public class Principal {
 public static void main(String[] args) {
 FrmLogin ventana1=new FrmLogin();
 ventana1.setVisible(true);
 }
 }
