/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;
import modelo.Facturas;
import java.io.FileWriter;
import java.io.IOException;
public class Cfactura {
    public void Registar(Facturas nueva) throws IOException{
 String ruta ="Facturas.txt";
 FileWriter BaseDeDatos = new FileWriter(ruta,true); 
 BaseDeDatos.append(nueva.getCliente()+"::"+nueva.getDireccion()+"::"+
 nueva.getMes()+"::"+nueva.getTotalapagar()+":\r\n");
 BaseDeDatos.close();
 }
}
