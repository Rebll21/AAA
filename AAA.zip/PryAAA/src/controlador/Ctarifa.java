/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Tarifa;
import java.io.FileWriter;
import java.io.IOException;

public class Ctarifa {
    public void Registar(Tarifa nueva) throws IOException{
 String ruta ="Tarifas.txt";
 FileWriter BaseDeDatos = new FileWriter(ruta,true); 
 BaseDeDatos.append(nueva.getNombre()+"::"+nueva.getFecha()+"::"+
 nueva.getConsumo()+"::"+nueva.getTarifa()+"\r\n");
 BaseDeDatos.close();
 }
}
