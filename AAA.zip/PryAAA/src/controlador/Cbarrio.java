/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Barrio;
import java.io.FileWriter;
import java.io.IOException;
public class Cbarrio {
     public void Registar(Barrio nueva) throws IOException{
 String ruta ="Barrios.txt";
 FileWriter BaseDeDatos = new FileWriter(ruta,true); 
 BaseDeDatos.append(nueva.getBarrio()+":\r\n");
 BaseDeDatos.close();
 }
}
