/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Lecturas;
import java.io.FileWriter;
import java.io.IOException;
public class Clectura {
    public void Registar(Lecturas nueva) throws IOException{
 String ruta ="Lecturas.txt";
 FileWriter BaseDeDatos = new FileWriter(ruta,true); 
 BaseDeDatos.append(nueva.getNpoliza()+"::"+nueva.getLecturaanterior()+"::"+
 nueva.getNombrelector()+"::"+nueva.getLecturaactual()+"\r\n");
 BaseDeDatos.close();
 }
}
