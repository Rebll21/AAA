/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Municipio;
import java.io.FileWriter;
import java.io.IOException;
public class Cmunicipio {
    public void Registar(Municipio nueva) throws IOException{
 String ruta ="Municipios.txt";
 FileWriter BaseDeDatos = new FileWriter(ruta,true); 
 BaseDeDatos.append(nueva.getMunicipio()+":\r\n");
 BaseDeDatos.close();
 }
}
